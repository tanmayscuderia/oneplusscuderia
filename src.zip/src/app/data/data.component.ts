import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css'],
  providers:[DataServiceService]
})
export class DataComponent implements OnInit {
  ninjas = {};
  akshay = "akshay";
  
  constructor(private dataService : DataServiceService) {
    
   }

  ngOnInit() {
    this.dataService.fetchData().subscribe(
    (data) => this.ninjas = data
    );
  }

}
