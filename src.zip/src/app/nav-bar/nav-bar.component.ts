import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  tab = 1;
  one = 1;
  two = 2;
  three = 3;
  
  setTab(tabS){
    this.tab = tabS;
  }

  constructor() { }

  ngOnInit() {
  }

}
